bootloader.bin                	0x0 
partition-table.bin          	0x8000
usb_camera_mic_spk.bin           0x100000

